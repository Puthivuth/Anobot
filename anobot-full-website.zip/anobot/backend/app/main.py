from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings

app = FastAPI(title="AnoBot API", version="0.1.0", description="Computer vision dataset, training and inference platform")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.web_origin],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-CSRF-Token"],
)

@app.get("/health", tags=["system"])
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "anobot-api"}

@app.get("/api/v1/auth/status", tags=["auth"])
async def auth_status() -> dict[str, bool]:
    # Phase 2 will check the database for the first-run setup state.
    return {"needs_setup": True}
